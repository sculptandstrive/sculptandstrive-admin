import { useState, useEffect } from "react";
import { 
  Calendar as CalendarIcon, Video, Users as UsersIcon,  
  Clock, Plus, Trash2, RefreshCw, Search
} from "lucide-react";
import { useGoogleLogin } from '@react-oauth/google'; 
import { supabase } from "@/integrations/supabase/client";
import { DashboardLayout } from "@/components/DashboardLayout";
import { PageHeader } from "@/components/PageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Dialog, DialogContent, DialogHeader, 
  DialogTitle, DialogTrigger, DialogFooter 
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";

export default function Sessions() {
  const [sessions, setSessions] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]); 
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [isPublishing, setIsPublishing] = useState(false);
  const [sessionType, setSessionType] = useState<"individual" | "group">("individual");
  const [selectedGroup, setSelectedGroup] = useState("");
  const [groups, setGroups] = useState<any[]>([]);

  const {user} = useAuth();

  const filteredClients = clients.filter(client => 
    client.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    client.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const today = new Date().toISOString().split('T')[0];

  const sessionRegex = [ 
    {
      platform: "google_meet",
      regex: /https?:\/\/meet\.google\.com\/[a-z]{3}-[a-z]{4}-[a-z]{3}/,
    },
    {
      platform: "zoom",
      regex: /^(https?:\/\/)?(www\.)?([a-z0-9-]+\.)?zoom\.us\/(j|wc)\/\d+$/i,
    },
    {
      platform: "whatsapp",
      regex: /^(https?:\/\/)?(www\.)?(wa\.me\/\d+|chat\.whatsapp\.com\/[A-Za-z0-9]+)$/i,
    },
    {
      platform: "youtube",
      regex: /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/,
      regex2: /^(https?:\/\/)?(www\.)?youtube\.com\/shorts\/[\w-]+$/i
    },
  ];

  const getNearestHourTime = () => {
    const now = new Date();
    now.setMinutes(0, 0, 0); 
    now.setHours(now.getHours() + 1); 
    return now.toTimeString().slice(0, 5); 
  };

  const [formData, setFormData] = useState({
    title: "",
    trainer: "",
    platform: "zoom",
    type: "live", 
    link: "",
    date: today,
    time: getNearestHourTime(),
    isMass: true,
    selectedClientIds: [] as string[]
  });

  const fetchData = async () => {
    setLoading(true);
    try {
     const { data: roleData, error: roleErr } = await supabase
       .from("user_roles")
       .select("user_id")
       .eq("role", "user");

     if (roleErr) {
       console.error("Role fetch error:", roleErr);
       return;
     }

     const userIds = roleData.map((r) => r.user_id);

     const [sessRes, clientRes] = await Promise.all([
       supabase
         .from("sessions")
         .select("*, session_assignments(client_id)")
         .order("created_at", { ascending: false }),
       supabase
         .from("profiles")
         .select("user_id, full_name, email")
         .in("user_id", userIds)
         .order("created_at", { ascending: false }),
     ]);
      
      if (sessRes.error) throw sessRes.error;
      setSessions(sessRes.data || []);
      if (clientRes.data) setClients(clientRes.data);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchGroups = async () => {
    try {
      const { data, error } = await supabase
        .from("workout_groups")
        .select("id, name")
        .order("name", { ascending: true });
      
      if (error) throw error;
      setGroups(data || []);
    } catch (error: any) {
      console.error("Error fetching groups:", error);
    }
  };

  useEffect(() => { 
    const profileSubscription = supabase
      .channel('admin-profile-sync')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, () => fetchData())
      .subscribe();

    const getProfile = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          const { data } = await supabase
            .from("profiles")
            .select("full_name")
            .eq("user_id", user.id)
            .maybeSingle();
            
          if (data?.full_name) {
            setFormData(prev => ({ ...prev, trainer: data.full_name }));
          }
        }
      } catch (err) {
        console.error("Auth error:", err);
      }
    };

    getProfile();
    fetchData(); 
    fetchGroups();

    return () => {
      supabase.removeChannel(profileSubscription);
    };
  }, []);

  const generateMeetLink = useGoogleLogin({
    onSuccess: async (tokenResponse) => {
      const toastId = toast.loading("Generating Google Meet link...");
      try {
        const startDateTime = new Date(`${formData.date}T${formData.time}`).toISOString();
        const endDate = new Date(`${formData.date}T${formData.time}:00Z`);
        endDate.setHours(endDate.getHours() + 1);
        const endDateTime = endDate.toISOString();

        const response = await fetch(
          "https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1",
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${tokenResponse.access_token}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              summary: formData.title || "Fitness Session",
              description: `Trainer: ${formData.trainer}`,
              start: { dateTime: startDateTime },
              end: { dateTime: endDateTime }, 
              conferenceData: {
                createRequest: {
                  requestId: Math.random().toString(36).substring(7),
                  conferenceSolutionKey: { type: "hangoutsMeet" },
                },
              },
            }),
          }
        );

        const data = await response.json();
        if (data.hangoutLink) {
          setFormData(prev => ({ ...prev, link: data.hangoutLink, platform: 'google_meet' }));
          toast.success("Google Meet link ready!", { id: toastId });
        } else {
          toast.error("Google rejected the request.", { id: toastId });
        }
      } catch (error) {
        toast.error("Generation failed.", { id: toastId });
      }
    },
    scope: 'https://www.googleapis.com/auth/calendar.events',
  });

  const getLiveStatus = (scheduledAt: string, type: string) => {
    if (type === 'recorded') return false; 
    const startTime = new Date(scheduledAt).getTime();
    const now = new Date().getTime();
    const duration = 60 * 60 * 1000; 
    return now >= startTime && now <= (startTime + duration);
  };

  const isPastSession = (scheduledAt: string, type: string) => {
    const startTime = new Date(scheduledAt).getTime();
    const now = new Date().getTime();

    if (type === 'recorded') {
      const SEVEN_DAYS = 7 * 24 * 60 * 60 * 1000;
      return now > (startTime + SEVEN_DAYS); 
    }

    const duration = 60 * 60 * 1000; 
    return now > (startTime + duration);
  };

  const handleToggleClient = (clientId: string) => {
    setFormData(prev => ({
      ...prev,
      selectedClientIds: prev.selectedClientIds.includes(clientId)
        ? prev.selectedClientIds.filter(id => id !== clientId)
        : [...prev.selectedClientIds, clientId]
    }));
  };

  const getVideoDuration = (file: File): Promise<number> => {
    return new Promise((resolve, reject) => {
      const video = document.createElement("video");
      video.preload = "metadata";
      video.src = URL.createObjectURL(file);
      video.onloadedmetadata = () => {
        URL.revokeObjectURL(video.src);
        resolve(video.duration);
      };
      video.onerror = reject;
    });
  };

  const handleVideoUpload = async(e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if(!file){
      return;
    }

    const allowedTypes = ["video/mp4"]
    const maxSize = 50 * 1024 * 1024;

    if(!allowedTypes.includes(file.type)){
      toast.error("Video Format should be mp4 only")
      e.target.value = "";
      return;
    }

    if(file.size > maxSize){
      toast.error("Video Size Should be less than 50 MB")
      e.target.value = "";
      return;
    }

    const duration = await getVideoDuration(file)
    if(duration > 60){
      toast.error("Video Duration should be less than 60 seconds")
       e.target.value = "";
        return;
    }

    setLoading(true);

    const fileExt = file.name.split(".").pop();
    const filePath = `${Date.now()}.${fileExt}`;

    const {error: uploadError} = await supabase.storage.from('tutorials').upload(filePath, file, {upsert: true})

    if(uploadError){
      toast.error("Video Not Uploaded")
      e.target.value = "";
      setLoading(false)
      return;
    }

    const {data} = await supabase.storage.from('tutorials').getPublicUrl(filePath);
    console.log(data.publicUrl)
    setFormData({...formData, link: data.publicUrl})
    setLoading(false)
    return;
  }

  const handleAddSession = async () => {
    if(formData.type === "live"){
      if (!formData.link || !formData.title) return toast.error("Title and Link are required");
    }
    if (isPublishing) return;

    const scheduledDateTime = new Date(`${formData.date}T${formData.time}:00`);
    const now = new Date();
    
    if (formData.type === "live" && formData.platform) {
      const platformDetails = sessionRegex.find((p) => p.platform === formData.platform);
      if (platformDetails) {
        const isValid = platformDetails.regex.test(formData.link) || (platformDetails.regex2 && platformDetails.regex2.test(formData.link));
        if (!isValid) {
          toast.error(`Please Give Correct ${formData.platform} Link`);
          return;
        }
      }
    }

    if (formData.type === 'live' && scheduledDateTime <= now) {
      toast.error("Please select a future time for live sessions");
      return;
    }

    setIsPublishing(true);

    try {
        const { data: newSession, error: sessErr } = await supabase.from("sessions").insert([{
          title: formData.title,
          instructor: formData.trainer || "Coach",
          platform: formData.platform,
          type: formData.type, 
          meeting_link: formData.link,
          scheduled_at: scheduledDateTime.toISOString(),
          admin_is_mass: formData.isMass,
          admin_status: "upcoming"
        }]).select().single();

        if (sessErr) {
            toast.error(sessErr.message);
            setIsPublishing(false); 
            return;
        }

        if (!formData.isMass && formData.selectedClientIds.length > 0 && formData.type === "live") {
          const assignments = formData.selectedClientIds.map(cid => ({ 
            session_id: newSession.id, 
            client_id: cid 
          }));

          const notifications = formData.selectedClientIds.map((cid) => ({
            user_id: cid,
            title: `You have a new Session: ${formData.title}`,
            description: `Join the session at ${scheduledDateTime.toLocaleTimeString(
              [],
              {
                hour: "2-digit",
                minute: "2-digit",
              },
            )}`,
            notification_date: scheduledDateTime.toISOString().split("T")[0],
            related_id: newSession.id,
          }));

          const { error: notificationError, data: notificationData } = await supabase
            .from("notifications")
            .insert(notifications);
        
          const { error: assignErr } = await supabase.from("session_assignments").insert(assignments);
          if (assignErr) toast.error("Session created, but user assignment failed.");
        }
        else if(formData.isMass && formData.type === "live"){
          const notifications = filteredClients.map((cid) => ({
            user_id: cid.user_id,
            title: `New Session: ${formData.title}`,
            description: `Join the session at ${scheduledDateTime.toLocaleTimeString(
              [],
              {
                hour: "2-digit",
                minute: "2-digit",
              },
            )}`,
            notification_date: scheduledDateTime.toISOString().split("T")[0], 
            related_id: newSession.id
          }));

          const { error: notificationError, data: notificationData } = await supabase
            .from("notifications")
            .insert(notifications);

        }

        await supabase.from("activities").insert([{
          admin_user_name: formData.trainer || "Coach",
          admin_action_detail: `Scheduled ${formData.type} session: ${formData.title}`,
          admin_activity_type: formData.type === 'recorded' ? 'video' : 'session',
          admin_created_at: new Date().toISOString()
        }]);

        toast.success("Session published successfully!");
        setIsModalOpen(false);
        setSearchTerm("");
        setFormData({
          title: "", trainer: formData.trainer, platform: "zoom", type: "live", link: "",
          date: today, time: getNearestHourTime(), isMass: true, selectedClientIds: []
        });
        fetchData();
    } catch (err: any) {
        toast.error("An unexpected error occurred");
    } finally {
        setIsPublishing(false);
    }
  };

  const handleDelete = async (id: string, title: string, trainer: string) => {
    if (!confirm(`Are you sure you want to delete "${title}"?`)) return;
    const { error } = await supabase.from("sessions").delete().eq("id", id);
    const {error: notificatinDelError} = await supabase.from('notifications').delete().eq('related_id', id);
    if (!error) {
      await supabase.from("activities").insert([{
        admin_user_name: trainer || "Coach",
        admin_action_detail: `Deleted session: ${title}`,
        admin_activity_type: "deletion",
        admin_created_at: new Date().toISOString()
      }]);
      toast.success("Session removed");
      fetchData();
    }
  };

  return (
    <>
      <PageHeader
        title="Sessions"
        description="Manage your Live workouts and Recorded Library."
      >
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={fetchData}
            className="text-slate-400 shrink-0 h-9 w-9"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
          <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#0ea5e9] hover:bg-[#0ea5e9]/90 text-white shadow-sm whitespace-nowrap text-xs h-9 px-3">
                <Plus className="w-3.5 h-3.5 mr-1.5" /> Add
              </Button>
            </DialogTrigger>
            <DialogContent className="w-[95vw] sm:max-w-[550px] max-h-[90vh] overflow-y-auto overflow-x-hidden p-5">
              <DialogHeader>
                <DialogTitle className="text-base">Schedule New Session</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-2">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="grid gap-1.5">
                    <Label className="text-xs text-slate-600">Session Type</Label>
                    <Select
                      value={formData.type}
                      onValueChange={(v) =>
                        setFormData({ ...formData, type: v })
                      }
                    >
                      <SelectTrigger className="border-slate-200 bg-slate-50/50 h-9 text-sm">
                        <SelectValue placeholder="Select Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="live">Live Streaming</SelectItem>
                        <SelectItem value="recorded">Recorded Library</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs text-slate-600">Trainer / Coach</Label>
                    <Input
                      value={formData.trainer}
                      className="border-slate-200 h-9 text-sm"
                      placeholder="Coach name"
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          trainer: e.target.value.slice(0, 40),
                        })
                      }
                    />
                  </div>
                  <div className="grid gap-1.5">
                    <Label className="text-xs text-slate-600">Session Type</Label>
                    <Select
                      value={sessionType}
                      onValueChange={(v) => setSessionType(v as "individual" | "group")}
                    >
                      <SelectTrigger className="border-slate-200 bg-slate-50/50 h-9 text-sm">
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="individual">👤 Individual</SelectItem>
                        <SelectItem value="group">👥 Group</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {sessionType === "group" && (
                    <div className="grid gap-1.5">
                      <Label className="text-xs text-slate-600">Select Group</Label>
                      <Select value={selectedGroup} onValueChange={setSelectedGroup}>
                        <SelectTrigger className="border-slate-200 bg-slate-50/50 h-9 text-sm">
                          <SelectValue placeholder="Choose a group..." />
                        </SelectTrigger>
                        <SelectContent>
                          {groups.map((g) => (
                            <SelectItem key={g.id} value={g.id}>
                              {g.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                <div className="grid gap-1.5">
                  <Label className="text-xs text-slate-600">Session Title</Label>
                  <Input
                    value={formData.title}
                    className="border-slate-200 h-9 text-sm"
                    placeholder="e.g. Morning Cardio"
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        title: e.target.value.slice(0, 40),
                      })
                    }
                  />
                </div>

                {formData.type === "live" ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="grid gap-1.5">
                      <Label className="text-xs text-slate-600">Date</Label>
                      <Input
                        type="date"
                        min={today}
                        className="border-slate-200 h-9 text-sm"
                        value={formData.date}
                        onChange={(e) =>
                          setFormData({ ...formData, date: e.target.value })
                        }
                      />
                    </div>
                    <div className="grid gap-1.5">
                      <Label className="text-xs text-slate-600">Time</Label>
                      <Input
                        type="time"
                        className="border-slate-200 h-9 text-sm"
                        value={formData.time}
                        onChange={(e) =>
                          setFormData({ ...formData, time: e.target.value })
                        }
                      />
                    </div>
                  </div>
                ) : (
                  <></>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-blue-50/50 border border-blue-100 rounded-lg">
                  <div>
                    <Label className="text-[10px] font-semibold uppercase tracking-wider text-blue-600">
                      Visibility Mode
                    </Label>
                    <p className="text-[10px] text-blue-400">
                      Who can see this{" "}
                      {formData.type === "live" ? "session" : "library video"}?
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-400">Private</span>
                    <Switch
                      checked={formData.isMass}
                      onCheckedChange={(v) =>
                        setFormData({ ...formData, isMass: v })
                      }
                    />
                    <span className="text-[10px] text-slate-600 font-medium">
                      Public (All)
                    </span>
                  </div>
                </div>

                {!formData.isMass && (
                  <div className="border rounded-xl p-3 sm:p-4 bg-slate-900/90 border-slate-700 max-w-full overflow-hidden">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-3 gap-3">
                      <Label className="text-xs font-semibold text-[#0ea5e9]">
                        Assign to Clients ({formData.selectedClientIds.length})
                      </Label>
                      <div className="relative w-full sm:w-auto sm:flex-1">
                        <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-400" />
                        <Input
                          placeholder="Search name..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="h-8 text-xs pl-7 pr-2 border-slate-700 bg-slate-800 text-white w-full placeholder:text-slate-500"
                        />
                      </div>
                    </div>
                    <ScrollArea className="h-[120px] pr-2">
                      {filteredClients.length === 0 ? (
                        <p className="text-[10px] text-slate-400 text-center py-4">
                          No matching clients found.
                        </p>
                      ) : (
                        filteredClients.map((client) => {
                          return (
                            <div
                              key={client.user_id}
                              className="flex items-center justify-between py-2 border-b border-slate-800 last:border-0 mr-1"
                            >
                              <div className="flex flex-col min-w-0 flex-1 mr-2">
                                <span className="text-xs font-medium text-white truncate">
                                  {client.full_name.length > 40
                                    ? client.full_name.slice(0, 40) + "..."
                                    : client.full_name}
                                </span>
                                <span className="text-[9px] text-slate-500 uppercase font-mono">
                                  {client.user_id.slice(0, 8)}...
                                </span>
                              </div>
                              <Checkbox
                                checked={formData.selectedClientIds.includes(
                                  client.user_id,
                                )}
                                onCheckedChange={() =>
                                  handleToggleClient(client.user_id)
                                }
                                className="shrink-0 border-slate-500 data-[state=checked]:bg-[#0ea5e9] data-[state=checked]:border-[#0ea5e9]"
                              />
                            </div>
                          );
                        })
                      )}
                    </ScrollArea>
                  </div>
                )}

                {formData.type === "live" ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="grid gap-1.5">
                      <Label className="text-xs text-slate-600">Platform</Label>
                      <Select
                        value={formData.platform}
                        onValueChange={(v) =>
                          setFormData({ ...formData, platform: v })
                        }
                      >
                        <SelectTrigger className="border-slate-200 h-9 text-sm">
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="zoom">Zoom</SelectItem>
                          <SelectItem value="google_meet">Google Meet</SelectItem>
                          <SelectItem value="whatsapp">WhatsApp</SelectItem>
                          <SelectItem value="youtube">YouTube</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid gap-1.5">
                      <div className="flex items-center justify-between">
                        <Label className="text-xs text-slate-600">Video Link</Label>
                        <Button
                          type="button"
                          variant="ghost"
                          className="h-6 text-[10px] text-[#0ea5e9] px-2 flex items-center gap-1"
                          onClick={() => generateMeetLink()}
                        >
                          <Video className="w-3 h-3" /> Auto-Meet
                        </Button>
                      </div>
                      <Input
                        className="border-slate-200 h-9 text-sm"
                        placeholder="Paste link here..."
                        value={formData.link}
                        onChange={(e) =>
                          setFormData({ ...formData, link: e.target.value })
                        }
                      />
                    </div>
                  </div>
                ) : (
                  <div className="grid gap-1.5">
                    <Label className="text-xs text-slate-600">Choose File</Label>
                    <Input
                      type="file"
                      className="border-slate-200 h-9 text-sm"
                      onChange={handleVideoUpload}
                    />
                  </div>
                )}
              </div>
              <DialogFooter className="mt-2">
                <Button
                  onClick={handleAddSession}
                  disabled={isPublishing}
                  className="w-full bg-[#0ea5e9] hover:bg-[#0ea5e9]/90 text-white font-semibold text-sm h-9"
                >
                  {isPublishing
                    ? "Publishing..."
                    : formData.type === "recorded"
                      ? loading ? "Uploading..." : "Add to Library"
                      : "Publish Live Session"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </PageHeader>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-6">
        <StatCard
          title="Live Now"
          value={
            sessions.filter((s) => getLiveStatus(s.scheduled_at, s.type)).length
          }
          icon={<Video className="w-4 h-4 text-[#0ea5e9]" />}
          bgColor="bg-sky-50"
        />
        <StatCard
          title="Total Workouts"
          value={sessions.length}
          icon={<CalendarIcon className="w-4 h-4 text-[#0ea5e9]" />}
          bgColor="bg-sky-50"
        />
        <StatCard
          title="Active Clients"
          value={clients.length}
          icon={<UsersIcon className="w-4 h-4 text-slate-400" />}
          bgColor="bg-slate-50"
        />
      </div>

      <Card className="border-none shadow-sm overflow-hidden">
        <CardHeader className="px-5 py-4">
          <CardTitle className="text-base font-semibold text-foreground">
            Session Management
          </CardTitle>
        </CardHeader>
        <CardContent className="px-5 pb-5">
          <div className="space-y-2.5">
            {loading ? (
              <p className="text-center py-4 text-slate-400 text-sm">
                Syncing database...
              </p>
            ) : sessions.length === 0 ? (
              <p className="text-center py-4 text-slate-400 text-sm">
                No sessions scheduled.
              </p>
            ) : (
              sessions.map((session) => {
                const isLive = getLiveStatus(
                  session.scheduled_at,
                  session.type,
                );
                const isPast = isPastSession(
                  session.scheduled_at,
                  session.type,
                );
                const participantCount = session.admin_is_mass
                  ? "ALL"
                  : session.session_assignments?.length || 0;
                const sessionTime = new Date(
                  session.scheduled_at,
                ).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                  hour12: false,
                });

                return (
                  <div
                    key={session.id}
                    className={`group flex flex-col sm:flex-row sm:items-center gap-3 p-4 rounded-xl border transition-all ${
                      isPast
                        ? "opacity-50 bg-slate-50/30 border-slate-100 grayscale-[0.5]"
                        : "hover:border-sky-100 hover:bg-sky-50/30 border-slate-200"
                    }`}
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-1">
                        <h4 className="font-semibold text-base text-foreground truncate max-w-[200px] sm:max-w-none">
                          {session.title}
                        </h4>
                        <div className="flex gap-1">
                          {isLive && (
                            <Badge className="bg-[#0ea5e9] text-white text-[9px] uppercase font-semibold px-1.5 py-0.5">
                              LIVE
                            </Badge>
                          )}
                          {isPast && (
                            <Badge
                              variant="secondary"
                              className="text-[9px] bg-slate-200 text-slate-500 border-none uppercase px-1.5 py-0.5"
                            >
                              PAST
                            </Badge>
                          )}
                          {session.admin_is_mass && (
                            <Badge
                              variant="outline"
                              className="text-[9px] border-blue-200 text-blue-500 uppercase px-1.5 py-0.5"
                            >
                              PUBLIC
                            </Badge>
                          )}
                        </div>
                      </div>
                      <p className="text-sm text-slate-400 font-medium capitalize truncate">
                        Coach {session.instructor}
                      </p>
                    </div>

                    <div className="flex items-center flex-wrap gap-2 sm:gap-4">
                      <div className="flex items-center gap-1.5 text-slate-500 bg-white px-2 py-1.5 rounded-lg border border-slate-100">
                        {session.type === "recorded" ? (
                          <Video className="w-3.5 h-3.5 text-purple-500" />
                        ) : (
                          <Clock className="w-3.5 h-3.5 text-[#0ea5e9]" />
                        )}
                        <span className="text-xs font-semibold">
                          {session.type === "recorded"
                            ? "Library"
                            : sessionTime}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-500 bg-white px-2 py-1.5 rounded-lg border border-slate-100 min-w-[80px]">
                        <UsersIcon className="w-3.5 h-3.5 text-slate-400" />
                        <span className="text-xs font-semibold">
                          {participantCount} Clients
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-1.5 border-t sm:border-t-0 pt-2 sm:pt-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-[#0ea5e9] text-sm font-semibold hover:bg-sky-50 h-9 px-2.5"
                        onClick={() =>
                          window.open(session.meeting_link, "_blank")
                        }
                      >
                        View
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-slate-300 hover:text-red-500 hover:bg-red-50 h-8 w-8"
                        onClick={() =>
                          handleDelete(
                            session.id,
                            session.title,
                            session.instructor,
                          )
                        }
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </>
  );
}

function StatCard({ title, value, icon, bgColor }: any) {
  return (
    <Card className="border-none shadow-sm">
      <CardContent className="pt-5 flex items-center justify-between gap-4">
        <div className="min-w-0 flex-1">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-1 truncate">{title}</p>
          <p className="text-2xl font-bold text-foreground">{value}</p>
        </div>
        <div className={`h-10 w-10 rounded-xl flex items-center justify-center shrink-0 ${bgColor}`}>{icon}</div>
      </CardContent>
    </Card>
  );
}